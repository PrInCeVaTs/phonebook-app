# rentomojo2
this is a phone book web app 

and i have added booststrap table for showing the phone details .
i have used bootstrap and oops concept for it.
in the table name  are added by clicking on it you can see the details of the phone number ,email and dob.
then at right bottom a plus button is given by using a phone details can be added.
by default all the details are sorted accoriding to dates but you can sort according to your choice for example exmail,names and phone numbers.
And it is a responsive website.
thankyou.
 below is website link
http://myphonebook.atspace.cc/index.php
